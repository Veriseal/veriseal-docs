---
id: evidence-infrastructure
title: Infrastructura Dovezilor
---

﻿---
title: Infrastructura Dovezilor
sidebar_position: 1
---

# Infrastructura Dovezilor

## Nucleul dovezii
Hashing, rădăcini Merkle, registru doar adăugare, JSON public determinist.

## Separarea straturilor
Backend vs interfața publică de verificare UI vs renderer PDF (doar redare).

## Legătură puternică
Leagă jurnalul UX + media + registru + JSON (+ PDF/OTS când este activat).

## Operațiuni
Implementare suverană, TLS întărit, chei controlate, automatizare OTS programată.