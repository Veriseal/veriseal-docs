---
title: Foaie de parcurs instituțională — 36 luni
---

# Foaie de parcurs instituțională — 36 luni

## Faza 1 (0–12 luni)

- Integrări pilot
- Validare specifică sectorului
- Dialog cu autoritățile de reglementare
- Cadru inițial de certificare

Focus: implementare controlată.

---

## Faza 2 (12–24 luni)

- Adoptare multi-instituțională
- Extinderea programului de conformitate
- Grupuri de lucru sectoriale
- Proiecte pilot de interoperabilitate transfrontalieră

Focus: extinderea ecosistemului.

---

## Faza 3 (24–36 luni)

- Discuții formale de standardizare
- Formarea unui consorțiu instituțional
- Poziționare de referință globală
- Alinierea organismului de certificare

Focus: consolidarea candidaturii pentru standard.

---

## Obiectiv strategic

În decurs de 36 de luni:

VeriSeal trece de la soluție de infrastructură  
la candidat de referință pentru integritate.